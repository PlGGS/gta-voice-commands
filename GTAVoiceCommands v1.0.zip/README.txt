/\/\/\/\/\/\/\/\/\/\/\/\/\
\ GTA Voice Commands 1.0 /
/ By: Blake Boris(PLGGS) \
\/\/\/\/\/\/\/\/\/\/\/\/\/

DESCRIPTION:
Tired of sifting through trainer menus, and wasting valuable time? 
Have you ever uttered the words, "Man, if only I had some program to
do this shit for me"? No? Me neither, but nowadays voice control is 
everywhere! Got an iPhone? Say hello to Siri. Got windows 10? Say 
hello to Cortana. Got GTA V? Wait, what? Yes, that's correct! We
might not have some good old happy half ass name like Siri, but
we finally do have voice commands in GTA V!

INSTALLATION:
1. Install the latest version of ScriptHookV.
2. Install the latest version of ScriptHookVDotNet.
3. Install the latest version of Native UI
3. Copy GTAVoiceCommands.dll and the bvc folder into your scripts folder inside of your Grand Theft Auto V folder.
4. Play the game in singleplayer (duh)

Please think about donating as it is very appriciated.

CONTACT:
Skype: picklepig7

LEGAL JARGON:
Feel free to use the source code for your own amusement, if you know how..
Do not upload this mod as your own in ANY scenario. If you make a modpack of some sort, and
use said mod, I would appreciate credit, but then again, who's going to use this simple of a mod in a pack?
Grand Theft Auto / GTA 5 are registered trademarks of Rockstar Games. This modification is not affiliated with or endorsed by Rockstar Games.
� 2016. Rockstar Games and its subsidiaries. All other marks and trademarks are the property of their respective owners. All rights reserved.

THERE IS ONE COMMAND NOT LISTED BELOW THAT IS A SECRET THAT PEOPLE WILL PROBABLY FIND...

COMMANDS LIST:
add money
wanted level up
wanted level down
wanted level max
wanted level null
toggle never wanted
toggle invincibility
toggle ignored by police
toggle ignored by everyone 'below is vehicle spawns
spawn vehicle Adder
spawn vehicle Airbus
spawn vehicle Airtug
spawn vehicle Akuma
spawn vehicle Alpha
spawn vehicle Ambulance
spawn vehicle Annihilator
spawn vehicle Army Tanker
spawn vehicle Army Trailer
spawn vehicle Army Trailer 2
spawn vehicle Asea
spawn vehicle Asea 2
spawn vehicle Asterope
spawn vehicle Bagger
spawn vehicle Bale Trailer
spawn vehicle Baller
spawn vehicle Baller 2
spawn vehicle Banshee
spawn vehicle Barracks
spawn vehicle Barracks 2
spawn vehicle Barracks 3
spawn vehicle Bati
spawn vehicle Bati 2
spawn vehicle Benson
spawn vehicle Besra
spawn vehicle Bf Injection
spawn vehicle Biff
spawn vehicle Bifta
spawn vehicle Bison
spawn vehicle Bison 2
spawn vehicle Bison 3
spawn vehicle BJXL
spawn vehicle Blade
spawn vehicle Blazer
spawn vehicle Blazer 2
spawn vehicle Blazer 3
spawn vehicle Blimp
spawn vehicle Blimp 2
spawn vehicle Blista
spawn vehicle Blista 2
spawn vehicle Blista 3
spawn vehicle Bmx
spawn vehicle Boat Trailer
spawn vehicle Bobcat XL
spawn vehicle Bodhi
spawn vehicle Boxville
spawn vehicle Boxville 2
spawn vehicle Boxville 3
spawn vehicle Boxville 4
spawn vehicle Brawler
spawn vehicle B Type
spawn vehicle Buccaneer
spawn vehicle Buffolo
spawn vehicle Buffolo 2
spawn vehicle Buffolo 3
spawn vehicle Bulldozer
spawn vehicle Bullet
spawn vehicle Burrito
spawn vehicle Burrito 2
spawn vehicle Burrito 3
spawn vehicle Burrito 4
spawn vehicle Burrito 5
spawn vehicle Bus
spawn vehicle Buzzard
spawn vehicle Buzzard 2
spawn vehicle Cable Car
spawn vehicle Caddy
spawn vehicle Caddy 2
spawn vehicle Camper
spawn vehicle Carbonizzare
spawn vehicle Carbon R5
spawn vehicle Cargobob
spawn vehicle Cargobob 2
spawn vehicle Cargobob 3
spawn vehicle Cargo Plane
spawn vehicle Casco
spawn vehicle Cavalcade
spawn vehicle Cavalcade 2
spawn vehicle Cheetah
spawn vehicle Chino
spawn vehicle Coach
spawn vehicle Cognoscenti Cabrio
spawn vehicle Comet
spawn vehicle Coquette
spawn vehicle Coquette 2
spawn vehicle Coquette 3
spawn vehicle Cruiser
spawn vehicle Crusader
spawn vehicle Cuban 800
spawn vehicle Cutter
spawn vehicle Daemon
spawn vehicle Dilettante
spawn vehicle Dilettante 2
spawn vehicle Dinghy
spawn vehicle Dinghy 2
spawn vehicle Dinghy 3
spawn vehicle D Loader
spawn vehicle Dock Trailer
spawn vehicle Dock Tug
spawn vehicle Dodo
spawn vehicle Dominator
spawn vehicle Dominator 2
spawn vehicle Double
spawn vehicle Dubsta
spawn vehicle Dubsta 2
spawn vehicle Dubsta 3
spawn vehicle Dukes
spawn vehicle Dukes 2
spawn vehicle Dump
spawn vehicle Dune
spawn vehicle Dune 2
spawn vehicle Duster
spawn vehicle Elegy
spawn vehicle Emperor
spawn vehicle Emperor 2
spawn vehicle Emperor 3
spawn vehicle Enduro
spawn vehicle Entity XF
spawn vehicle Exemplar
spawn vehicle F 620
spawn vehicle Faggio
spawn vehicle FBI
spawn vehicle FBI 2
spawn vehicle Felon
spawn vehicle Felon 2
spawn vehicle Feltzer
spawn vehicle Feltzer 2
spawn vehicle Firetruck
spawn vehicle Fixter
spawn vehicle Flatbed
spawn vehicle Forklift
spawn vehicle Fq 2
spawn vehicle Freight
spawn vehicle Freight Car
spawn vehicle Freight Container
spawn vehicle Freight Container 2
spawn vehicle Freight Grain
spawn vehicle Freight Trailer
spawn vehicle Frogger
spawn vehicle Frogger 2
spawn vehicle Fugitive
spawn vehicle Furoregt
spawn vehicle Fusilade
spawn vehicle Futo
spawn vehicle Gauntlet
spawn vehicle Gauntlet 2
spawn vehicle G Burrito
spawn vehicle G Burrito 2
spawn vehicle Glendale
spawn vehicle Grain Trailer
spawn vehicle Granger
spawn vehicle Gresley
spawn vehicle Guardian
spawn vehicle Habanero
spawn vehicle Hakuchou
spawn vehicle Handler
spawn vehicle Hauler
spawn vehicle Hexer
spawn vehicle Hotknife
spawn vehicle Huntley
spawn vehicle Hydra
spawn vehicle Infernus
spawn vehicle Ingot
spawn vehicle Innovation
spawn vehicle Insurgent
spawn vehicle Insurgent 2
spawn vehicle Intruder
spawn vehicle Issi 2
spawn vehicle Jackal
spawn vehicle JB 700
spawn vehicle Jester
spawn vehicle Jester 2
spawn vehicle Jet
spawn vehicle Jetmax
spawn vehicle Journey
spawn vehicle Kalahari
spawn vehicle Khamelion
spawn vehicle Kuruma
spawn vehicle Kuruma 2
spawn vehicle Land Stalker
spawn vehicle Laser
spawn vehicle Lectro
spawn vehicle L Guard
spawn vehicle Luxor
spawn vehicle Luxor 2
spawn vehicle Mammatus
spawn vehicle Manana
spawn vehicle Marquis
spawn vehicle Marshall
spawn vehicle Massacro
spawn vehicle Massacro 2
spawn vehicle Maverick
spawn vehicle Mesa
spawn vehicle Mesa 2
spawn vehicle Mesa 3
spawn vehicle Miljet
spawn vehicle Minivan
spawn vehicle Mixer
spawn vehicle Mixer 2
spawn vehicle Monroe
spawn vehicle Monster
spawn vehicle Mower
spawn vehicle Mule
spawn vehicle Mule 2
spawn vehicle Mule 3
spawn vehicle Nemesis
spawn vehicle Ninef
spawn vehicle Ninef 2
spawn vehicle Oracle
spawn vehicle Oracle 2
spawn vehicle Osiris
spawn vehicle Packer
spawn vehicle Panto
spawn vehicle Paradise
spawn vehicle Patriot
spawn vehicle P Bus
spawn vehicle PCJ
spawn vehicle Penumbra
spawn vehicle Peyote
spawn vehicle Phantom
spawn vehicle Phoenix
spawn vehicle Picador
spawn vehicle Pigalle
spawn vehicle Police
spawn vehicle Police 2
spawn vehicle Police 3
spawn vehicle Police 4
spawn vehicle Police B
spawn vehicle Police Old
spawn vehicle Police Old 2
spawn vehicle Police T
spawn vehicle Polmav
spawn vehicle Pony
spawn vehicle Pony 2
spawn vehicle Pounder
spawn vehicle Prairie
spawn vehicle Pranger
spawn vehicle Predator
spawn vehicle Premier
spawn vehicle Primo
spawn vehicle Prop Trailer
spawn vehicle Radi
spawn vehicle Rake Trailer
spawn vehicle Rancher XL
spawn vehicle Rancher XL 2
spawn vehicle Rapid GT
spawn vehicle Rapid GT 2
spawn vehicle Rat Loader
spawn vehicle Rat Loader 2
spawn vehicle Rebel
spawn vehicle Rebel 2
spawn vehicle Regina
spawn vehicle Rental Bus
spawn vehicle Rhapsody
spawn vehicle Rhino
spawn vehicle Riot
spawn vehicle Ripley
spawn vehicle Rocoto
spawn vehicle Romero
spawn vehicle Rubble
spawn vehicle Ruffian
spawn vehicle Ruiner
spawn vehicle Rumpo
spawn vehicle Rumpo 2
spawn vehicle Sabre GT
spawn vehicle Sadler
spawn vehicle Sadler 2
spawn vehicle Sanchez
spawn vehicle Sanchez 2
spawn vehicle Sandking
spawn vehicle Sandking 2
spawn vehicle Savage
spawn vehicle Schafter
spawn vehicle Schwarzer
spawn vehicle Scorcher
spawn vehicle Scrap
spawn vehicle Sea Shark
spawn vehicle Sea Shark 2
spawn vehicle Seminole
spawn vehicle Sentinal
spawn vehicle Sentinal 2
spawn vehicle Serrano
spawn vehicle Shamal
spawn vehicle Sheriff
spawn vehicle Sheriff 2
spawn vehicle Skylift
spawn vehicle Skylift 2
spawn vehicle Slam Van
spawn vehicle Slam Van 2
spawn vehicle Sovereign
spawn vehicle Speeder
spawn vehicle Speedo
spawn vehicle Speedo 2
spawn vehicle Squalo
spawn vehicle Stalion
spawn vehicle Stalion 2
spawn vehicle Stanier
spawn vehicle Stinger
spawn vehicle Stinger GT
spawn vehicle Stockade
spawn vehicle Stockade 2
spawn vehicle Stratum
spawn vehicle Stretch
spawn vehicle Stunt
spawn vehicle Submersible
spawn vehicle Submersible 2
spawn vehicle Sultan
spawn vehicle Suntrap
spawn vehicle Super Diamond
spawn vehicle Surano
spawn vehicle Surfer
spawn vehicle Surfer 2
spawn vehicle Surge
spawn vehicle Swift
spawn vehicle Swift 2
spawn vehicle T 20
spawn vehicle Taco
spawn vehicle Tailgater
spawn vehicle Tanker
spawn vehicle Tanker 2
spawn vehicle Tanker Car
spawn vehicle Taxi
spawn vehicle Technical
spawn vehicle Thrust
spawn vehicle Tip Truck
spawn vehicle Tip Truck 2
spawn vehicle Titan
spawn vehicle Tornado
spawn vehicle Tornado 2
spawn vehicle Tornado 3
spawn vehicle Tornado 4
spawn vehicle Toro
spawn vehicle Tour Bus
spawn vehicle Tow Truck
spawn vehicle Tow Truck 2
spawn vehicle TR
spawn vehicle TR 2
spawn vehicle TR 3
spawn vehicle TR 4
spawn vehicle Tractor
spawn vehicle Tractor 2
spawn vehicle Tractor 3
spawn vehicle Trailer Logs
spawn vehicle Trailers
spawn vehicle Trailers 2
spawn vehicle Trailers 3
spawn vehicle Trailer Small
spawn vehicle Trash
spawn vehicle Trash 2
spawn vehicle TR Flat
spawn vehicle Tri Bike
spawn vehicle Tri Bike 2
spawn vehicle Tri Bike 3
spawn vehicle Tropic
spawn vehicle Turismor
spawn vehicle TV Trailer
spawn vehicle Utility Truck
spawn vehicle Utility Truck 2
spawn vehicle Utility Truck 3
spawn vehicle Utilli Truck
spawn vehicle Utilli Truck 2
spawn vehicle Utilli Truck 3
spawn vehicle Vacca
spawn vehicle Vader
spawn vehicle Valkyrie
spawn vehicle Velum
spawn vehicle Velum 2
spawn vehicle Vestra
spawn vehicle Vigero
spawn vehicle Vindicator
spawn vehicle Virgo
spawn vehicle Voltic
spawn vehicle Voodoo
spawn vehicle Warrener
spawn vehicle Washington
spawn vehicle Windsor
spawn vehicle Youga
spawn vehicle Zentorno
spawn vehicle Zion
spawn vehicle Zion 2
spawn vehicle Z Type
spawn vehicle random'below is vehicle settings
repair vehicle
toggle vehicle invincibility
toggle vehicle strong wheels 'below is world settings
set weather extra sunny '0
set weather clear '1
set weather cloudy '2
set weather smog '3
set weather foggy '4
set weather overcast '5
set weather rain '6
set weather thunderstorm '7
set weather clearing '8
set weather neutral '9
set weather snow '10
set weather blizzard '11
set weather snowlight '12
add time one hour '0
subtract time one hour '1
set time morning '2
set time mid day '3
set time evening '4
set time midnight '5
toggle time pause
time system sync 'below is player settings
add weapon all '0
add weapon advanced rifle
add weapon assault rifle
add weapon assault shotgun
add weapon assault smg
add weapon bat
add weapon carbon rifle
add weapon combat pistol
add weapon crowbar
add weapon dagger
add weapon fire extinguisher
add weapon firework launcher
add weapon golf club
add weapon grenade
add weapon grenade launcher
add weapon hammer
add weapon hatchet
add weapon heavy pistol
add weapon heavy shotgun
add weapon heavy sniper
add weapon homing launcher
add weapon knife
add weapon marksman pistol
add weapon marksman rifle
add weapon micro smg
add weapon mini gun
add weapon molotov
add weapon musket
add weapon night stick
add weapon pistol
add weapon fifty cal
add weapon proximity mine
add weapon pump shotgun
add weapon rail gun
add weapon rpg
add weapon sawn off shotgun
add weapon smg
add weapon smoke grenade
add weapon sniper rifle
add weapon snowball
add weapon sns pistol
add weapon special carbine
add weapon sticky bomb
add weapon stun gun
add weapon vintage pistol

Version 1.0:
First major release.